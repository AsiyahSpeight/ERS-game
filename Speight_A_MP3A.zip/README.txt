README.txt file for CPSC-231 assignment MP3 at Chapman University 

AUTHOR INFO
Full name: Asiyah Speight 
Student ID: 2357167
Chapman Email: aspeight@chapman.edu 
Course number and section: CPSC-231-01
Assignment or exercise number: MP 3A - Cards

ERRORS 
No errors were detected while running the code.

SOURCES
A list of all references used to complete the assignment, including peers (if applicable)

LLM ChatGPT, was used only as a form of a "checker" to ensure the code had no syntax errors. Lecture material was used as a guide, specifically the lecture on classes, as ThreadsAccount class that was built in class was used as a guide, the driver for the class, the rest of the classes were built also using lecture material, and exam 2 review notes, more specifically, the bank account class, and the grocery store class were used as references to write the LinkedList and the Random number. 

Student Kevein Orpeza helped in the beginning of the driver code and the deck class code. as I was lost on what to do.